package com.postgres.poc.locationservicepostgres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationServicePostgresApplicationTests {

	@Test
	void contextLoads() {
	}

}
